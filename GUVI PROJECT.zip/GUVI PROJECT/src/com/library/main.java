package com.library;

import com.formdev.flatlaf.FlatIntelliJLaf;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.BorderFactory; // if this line shows error, change to: import javax.swing.BorderFactory;
import java.awt.*;

public class main {

    private static LibrarySystem librarySystem;

    private static DefaultTableModel bookTableModel;
    private static DefaultTableModel memberTableModel;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                FlatIntelliJLaf.install();
            } catch (Exception ex) {
                System.err.println("Failed to initialize LaF: " + ex.getMessage());
            }

            // ----- LOGIN DIALOG -----
            JTextField userField = new JTextField();
            JPasswordField passField = new JPasswordField();

            JPanel loginPanel = new JPanel(new GridLayout(2, 2, 5, 5));
            loginPanel.add(new JLabel("Username:"));
            loginPanel.add(userField);
            loginPanel.add(new JLabel("Password:"));
            loginPanel.add(passField);

            int result = JOptionPane.showConfirmDialog(
                    null,
                    loginPanel,
                    "Login",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE
            );

            if (result != JOptionPane.OK_OPTION) {
                System.exit(0);
            }

            String username = userField.getText().trim();
            String password = new String(passField.getPassword());

            UserDAO userDAO = new UserDAO();
            User user = userDAO.login(username, password);

            if (user == null) {
                JOptionPane.showMessageDialog(null, "Invalid username or password.");
                System.exit(0);
            }

            // ----- BACKGROUND LOAD (MULTITHREADING) -----
            JFrame loadingFrame = new JFrame("Loading Data...");
            loadingFrame.setSize(300, 100);
            loadingFrame.setLocationRelativeTo(null);
            loadingFrame.add(new JLabel("Please wait, loading library data...", SwingConstants.CENTER));
            loadingFrame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
            loadingFrame.setVisible(true);

            SwingWorker<LibrarySystem, Void> worker = new SwingWorker<>() {
                @Override
                protected LibrarySystem doInBackground() {
                    return new LibrarySystem(); // loads from DB on background thread
                }

                @Override
                protected void done() {
                    try {
                        librarySystem = get();
                        loadingFrame.dispose();

                        JFrame frame = new JFrame("Online Library Management System - " + user.getUsername());
                        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        frame.setSize(1000, 650);
                        frame.setLocationRelativeTo(null);

                        JTabbedPane tabbedPane = new JTabbedPane();
                        tabbedPane.setTabPlacement(JTabbedPane.TOP);
                        tabbedPane.setFont(new Font("Segoe UI", Font.PLAIN, 14));
                        tabbedPane.addTab("Librarian", createLibrarianPanel());
                        tabbedPane.addTab("Member", createMemberPanel());

                        frame.add(tabbedPane, BorderLayout.CENTER);
                        frame.setVisible(true);
                    } catch (Exception ex) {
                        loadingFrame.dispose();
                        JOptionPane.showMessageDialog(null, "Error loading data: " + ex.getMessage());
                        System.exit(1);
                    }
                }
            };

            worker.execute();
        });
    }

    // ----------------- LIBRARIAN TAB -----------------
    private static JPanel createLibrarianPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        JPanel statsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 5));
        JLabel totalLabel = new JLabel();
        JLabel availableLabel = new JLabel();
        JLabel issuedLabel = new JLabel();
        JButton addBookButton = new JButton("Add Book");
        addBookButton.putClientProperty("JButton.buttonType", "roundRect");
        JButton addMemberButton = new JButton("Add Member");
        addMemberButton.putClientProperty("JButton.buttonType", "roundRect");


        Runnable refreshStats = () -> {
            totalLabel.setText("Total: " + librarySystem.getTotalBooks());
            availableLabel.setText("Available: " + librarySystem.getAvailableBooks());
            issuedLabel.setText("Issued: " + librarySystem.getIssuedBooks());
        };

        statsPanel.add(totalLabel);
        statsPanel.add(availableLabel);
        statsPanel.add(issuedLabel);
        panel.add(statsPanel, BorderLayout.SOUTH);  // or NORTH under top panel


        // BOOK FORM (top)
        JPanel bookForm = new JPanel(new GridLayout(2, 4, 5, 5));
        JTextField titleField = new JTextField();
        JTextField authorField = new JTextField();
        JTextField isbnField = new JTextField();
        JTextField genreField = new JTextField();

        bookForm.add(new JLabel("Title:"));
        bookForm.add(titleField);
        bookForm.add(new JLabel("Author:"));
        bookForm.add(authorField);
        bookForm.add(new JLabel("ISBN:"));
        bookForm.add(isbnField);
        bookForm.add(new JLabel("Genre:"));
        bookForm.add(genreField);

        // BOOK TABLE
        String[] bookColumns = {"ID", "Title", "Author", "ISBN", "Genre", "Available"};
        bookTableModel = new DefaultTableModel(bookColumns, 0);
        JTable bookTable = new JTable(bookTableModel);
        bookTable.setRowHeight(24);
        JScrollPane bookScroll = new JScrollPane(bookTable);
        bookScroll.setBorder(BorderFactory.createTitledBorder("Books"));

        // load existing books from DB
        for (Book book : librarySystem.getBooks()) {
            bookTableModel.addRow(new Object[]{
                    book.getId(), book.getTitle(), book.getAuthor(),
                    book.getIsbn(), book.getGenre(), book.isAvailable()
            });
        }


        addBookButton.addActionListener(e -> {
            String title = titleField.getText().trim();
            String author = authorField.getText().trim();
            String isbn = isbnField.getText().trim();
            String genre = genreField.getText().trim();

            if (title.isEmpty() || author.isEmpty()) {
                JOptionPane.showMessageDialog(panel, "Title and Author are required.");
                return;
            }

            Book book = librarySystem.createBook(title, author, isbn, genre);
            if (book != null) {
                bookTableModel.addRow(new Object[]{
                        book.getId(), book.getTitle(), book.getAuthor(),
                        book.getIsbn(), book.getGenre(), book.isAvailable()
                });
            }

            titleField.setText("");
            authorField.setText("");
            isbnField.setText("");
            genreField.setText("");
        });

        // MEMBER FORM + TABLE (right side)
        JPanel memberPanel = new JPanel(new BorderLayout());
        memberPanel.setBorder(BorderFactory.createTitledBorder("Members"));

        JPanel memberForm = new JPanel(new GridLayout(2, 2, 5, 5));
        JTextField memberNameField = new JTextField();
        JTextField memberEmailField = new JTextField();

        memberForm.add(new JLabel("Member Name:"));
        memberForm.add(memberNameField);
        memberForm.add(new JLabel("Member Email:"));
        memberForm.add(memberEmailField);

        String[] memberColumns = {"ID", "Name", "Email"};
        memberTableModel = new DefaultTableModel(memberColumns, 0);
        JTable memberTable = new JTable(memberTableModel);
        memberTable.setRowHeight(24);
        JScrollPane memberScroll = new JScrollPane(memberTable);

        // load existing members from DB
        for (Member member : librarySystem.getMembers()) {
            memberTableModel.addRow(new Object[]{
                    member.getId(), member.getName(), member.getEmail()
            });
        }


        addMemberButton.addActionListener(e -> {
            String name = memberNameField.getText().trim();
            String email = memberEmailField.getText().trim();

            if (name.isEmpty() || email.isEmpty()) {
                JOptionPane.showMessageDialog(panel, "Name and Email are required.");
                return;
            }

            Member member = librarySystem.createMember(name, email);
            if (member != null) {
                memberTableModel.addRow(new Object[]{
                        member.getId(), member.getName(), member.getEmail()
                });
            }

            memberNameField.setText("");
            memberEmailField.setText("");
        });

        JPanel memberBottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        memberBottom.add(addMemberButton);

        memberPanel.add(memberForm, BorderLayout.NORTH);
        memberPanel.add(memberScroll, BorderLayout.CENTER);
        memberPanel.add(memberBottom, BorderLayout.SOUTH);

        // SPLIT: books left, members right
        JSplitPane splitPane = new JSplitPane(
                JSplitPane.HORIZONTAL_SPLIT,
                bookScroll,
                memberPanel
        );
        splitPane.setResizeWeight(0.5);

        JPanel top = new JPanel(new BorderLayout());
        top.add(bookForm, BorderLayout.NORTH);
        top.add(addBookButton, BorderLayout.SOUTH);

        panel.add(top, BorderLayout.NORTH);
        panel.add(splitPane, BorderLayout.CENTER);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        return panel;
    }

    // ----------------- MEMBER TAB -----------------
    private static JPanel createMemberPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Top: select member
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel memberLabel = new JLabel("Member:");
        JComboBox<Member> memberCombo = new JComboBox<>();
        JButton refreshMembersButton = new JButton("Load Members");

        topPanel.add(memberLabel);
        topPanel.add(memberCombo);
        topPanel.add(refreshMembersButton);
        JButton borrowButton = new JButton("Borrow Selected Book");
        borrowButton.putClientProperty("JButton.buttonType", "roundRect");

        JButton returnButton = new JButton("Return Selected Transaction");
        returnButton.putClientProperty("JButton.buttonType", "roundRect");

        refreshMembersButton.addActionListener(e -> {
            memberCombo.removeAllItems();
            for (Member m : librarySystem.getMembers()) {
                memberCombo.addItem(m);
            }
        });

        // Search controls
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JTextField searchField = new JTextField(18);
        searchField.setForeground(Color.GRAY);
        searchField.setText("Search books...");

        searchField.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent e) {
                if (searchField.getText().equals("Search books...")) {
                    searchField.setText("");
                    searchField.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(java.awt.event.FocusEvent e) {
                if (searchField.getText().isEmpty()) {
                    searchField.setForeground(Color.GRAY);
                    searchField.setText("Search books...");
                }
            }
        });

        String[] searchOptions = {"Title", "Author", "Genre"};
        JComboBox<String> searchByCombo = new JComboBox<>(searchOptions);
        JButton searchButton = new JButton("Search");


        searchPanel.add(new JLabel("Search:"));
        searchPanel.add(searchField);
        searchPanel.add(new JLabel("By:"));
        searchPanel.add(searchByCombo);
        searchPanel.add(searchButton);

        // Results table (available books)
        String[] bookCols = {"ID", "Title", "Author", "ISBN", "Genre", "Available"};
        DefaultTableModel searchTableModel = new DefaultTableModel(bookCols, 0);
        JTable resultTable = new JTable(searchTableModel);
        resultTable.setRowHeight(24);
        JScrollPane resultScroll = new JScrollPane(resultTable);
        resultScroll.setBorder(BorderFactory.createTitledBorder("Search Results"));

        // Borrowed (history) table
        String[] historyCols = {"TxID", "Book", "Borrow Date", "Return Date"};
        DefaultTableModel historyTableModel = new DefaultTableModel(historyCols, 0);
        JTable historyTable = new JTable(historyTableModel);
        historyTable.setRowHeight(24);
        JScrollPane historyScroll = new JScrollPane(historyTable);
        historyScroll.setBorder(BorderFactory.createTitledBorder("Borrowing History"));

        // Buttons borrow/return

        borrowButton.addActionListener(e -> {
            Member selectedMember = (Member) memberCombo.getSelectedItem();
            int row = resultTable.getSelectedRow();

            if (selectedMember == null) {
                JOptionPane.showMessageDialog(panel, "Select a member first.");
                return;
            }
            if (row == -1) {
                JOptionPane.showMessageDialog(panel, "Select a book in the search results.");
                return;
            }

            String bookId = (String) searchTableModel.getValueAt(row, 0);
            Book book = librarySystem.getBooks().stream()
                    .filter(b -> b.getId().equals(bookId))
                    .findFirst()
                    .orElse(null);

            if (book == null) {
                JOptionPane.showMessageDialog(panel, "Book not found.");
                return;
            }

            Transaction tx = librarySystem.borrowBook(book, selectedMember);
            if (tx == null) {
                JOptionPane.showMessageDialog(panel, "Book is not available.");
                return;
            }

            searchTableModel.setValueAt(false, row, 5);

            historyTableModel.addRow(new Object[]{
                    tx.getId(),
                    book.getTitle(),
                    tx.getBorrowDate(),
                    tx.getReturnDate()
            });

            librarySystem.loadBooks();
            librarySystem.loadTransactions();

            JOptionPane.showMessageDialog(panel, "Book borrowed successfully.");
        });

        returnButton.addActionListener(e -> {
            int row = historyTable.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(panel, "Select a transaction to return.");
                return;
            }

            String txId = (String) historyTableModel.getValueAt(row, 0);
            Transaction tx = librarySystem.getTransactions().stream()
                    .filter(t -> t.getId().equals(txId))
                    .findFirst()
                    .orElse(null);

            if (tx == null) {
                JOptionPane.showMessageDialog(panel, "Transaction not found.");
                return;
            }

            if (!librarySystem.returnBook(tx)) {
                JOptionPane.showMessageDialog(panel, "This transaction is already returned.");
                return;
            }

            historyTableModel.setValueAt(tx.getReturnDate(), row, 3);

            librarySystem.loadBooks();
            librarySystem.loadTransactions();

            JOptionPane.showMessageDialog(panel, "Book returned successfully.");
        });

        // Search action
        searchButton.addActionListener(e -> {
            String text = searchField.getText().trim().toLowerCase();
            if (text.equals("search books...")) text = "";
            String by = (String) searchByCombo.getSelectedItem();


            searchTableModel.setRowCount(0);

            if (text.isEmpty()) {
                JOptionPane.showMessageDialog(panel, "Enter some text to search.");
                return;
            }

            for (Book book : librarySystem.getBooks()) {
                String fieldValue;
                switch (by) {
                    case "Author" -> fieldValue = book.getAuthor();
                    case "Genre" -> fieldValue = book.getGenre();
                    default -> fieldValue = book.getTitle();
                }

                if (fieldValue != null && fieldValue.toLowerCase().contains(text)) {
                    searchTableModel.addRow(new Object[]{
                            book.getId(), book.getTitle(), book.getAuthor(),
                            book.getIsbn(), book.getGenre(), book.isAvailable()
                    });
                }
            }
        });

        memberCombo.addActionListener(e -> {
            Member selected = (Member) memberCombo.getSelectedItem();
            historyTableModel.setRowCount(0);
            if (selected == null) return;

            for (Transaction tx : librarySystem.getTransactions()) {
                if (tx.getMember().getId().equals(selected.getId())) {
                    historyTableModel.addRow(new Object[]{
                            tx.getId(),
                            tx.getBook().getTitle(),
                            tx.getBorrowDate(),
                            tx.getReturnDate()
                    });
                }
            }
        });

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(borrowButton);
        buttonPanel.add(returnButton);

        JSplitPane splitPane = new JSplitPane(
                JSplitPane.VERTICAL_SPLIT,
                resultScroll,
                historyScroll
        );
        splitPane.setResizeWeight(0.5);

        JPanel north = new JPanel(new BorderLayout());
        north.add(topPanel, BorderLayout.NORTH);
        north.add(searchPanel, BorderLayout.SOUTH);

        panel.add(north, BorderLayout.NORTH);
        panel.add(splitPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        return panel;
    }
}
